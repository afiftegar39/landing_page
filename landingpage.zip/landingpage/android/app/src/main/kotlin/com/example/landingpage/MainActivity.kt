package com.example.landingpage

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
